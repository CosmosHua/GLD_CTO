detectron2.config package
=========================

Related tutorials: :doc:`../tutorials/config`, :doc:`../tutorials/extend`.

.. automodule:: detectron2.config
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:


Config References
-----------------

.. literalinclude:: ../../detectron2/config/defaults.py
  :language: python
  :linenos:
  :lines: 4-
