from .show_result import show_result

__all__ = ['show_result']
