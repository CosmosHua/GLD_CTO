from .solov2 import SOLOv2
