adet.checkpoint package
=============================

.. automodule:: adet.checkpoint
    :members:
    :undoc-members:
    :show-inheritance: